import React, { useState } from 'react';
import './App.css';
import { 
  LayoutDashboard, 
  User, 
  Users, 
  ClipboardList, 
  MessageSquare, 
  Settings, 
  Search, 
  Bell, 
  Menu,
  TrendingUp,
  UserCheck,
  Clock,
  AlertCircle,
  Plus,
  BarChart2,
  FileText,
  Target,
  Send,
  PhoneCall,
  Calendar,
  AlertTriangle,
  ClipboardCheck,
  CalendarCheck,
  PhoneForwarded,
  Edit2,
  MapPin,
  Mail,
  Phone,
  Shield,
  CalendarDays,
  Save,
  X,
  Video,
  MessageCircle,
  MoreVertical,
  Play,
  CheckCheck
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';



function App() {
  const [voterData, setVoterData] = useState([
    { name: 'Jan', value1: 40, value2: 30 },
    { name: 'Feb', value1: 25, value2: 45 },
    { name: 'Mar', value1: 60, value2: 25 },
    { name: 'May', value1: 45, value2: 30 },
    { name: 'Jun', value1: 58, value2: 40 },
    { name: 'Jul', value1: 40, value2: 35 },
    { name: 'Aug', value1: 52, value2: 28 },
  ]);

  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const navItems = [
    { name: 'Dashboard', icon: LayoutDashboard },
    { name: 'User Profile', icon: User },
    { name: 'Contact & Meetings', icon: Calendar },
    { name: 'Complaints', icon: AlertTriangle },
    { name: 'Survey', icon: ClipboardCheck },
    { name: 'Attendance', icon: CalendarCheck },
    { name: 'Follow ups', icon: PhoneForwarded },
    { name: 'Voters List', icon: Users },
    { name: 'Tasks', icon: ClipboardList },
  ];

  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileData, setProfileData] = useState({
    fullName: 'Rahul Dev Sharma',
    dob: '1988-08-14',
    phone: '+91 98765 43210',
    email: 'rahul.sharma@party.com',
    address: '102, Sankalp Heights, Linking Road, Andheri West, Mumbai 400053',
    assignedWard: 'Ward 42 - Andheri West',
    primaryBooths: '104, 105, 106, 112',
    joinDate: '2023-01-15',
    epic: 'ABC1234567'
  });

  const [contactTab, setContactTab] = useState('contacts');
  const [isSchedulingMeeting, setIsSchedulingMeeting] = useState(false);
  const [meetingsList, setMeetingsList] = useState([
    { title: 'Booth Strategy Planning', time: 'Today, 4:00 PM', location: 'Ward 42 Office', attendees: '4 People', type: 'In-person' },
    { title: 'Weekly Campaign Sync', time: 'Tomorrow, 10:30 AM', location: 'Google Meet', attendees: '12 People', type: 'Virtual' },
    { title: 'Volunteer Training', time: 'Oct 5, 2:00 PM', location: 'Community Hall', attendees: '25 People', type: 'In-person' }
  ]);
  const [newMeeting, setNewMeeting] = useState({ title: '', time: '', location: '', attendees: '', type: 'Virtual' });

  const [complaintFilter, setComplaintFilter] = useState('All');

  const [complaintsData, setComplaintsData] = useState([
    { id: 'C-1001', name: 'Rajesh Kumar', phone: '+91 98765 12345', category: 'Water Supply', desc: 'No water supply in block 4 for 2 days', date: 'Oct 02, 2026', status: 'Pending' },
    { id: 'C-1002', name: 'Sneha Joshi', phone: '+91 87654 23456', category: 'Street Light', desc: 'Street light near main gate is broken', date: 'Oct 01, 2026', status: 'Resolved' },
    { id: 'C-1003', name: 'Vikas Singh', phone: '+91 76543 34567', category: 'Garbage', desc: 'Garbage not collected since Monday', date: 'Sep 30, 2026', status: 'In Progress' },
    { id: 'C-1004', name: 'Pooja Rane', phone: '+91 99887 45678', category: 'Road Repair', desc: 'Pothole needs filling near school', date: 'Sep 28, 2026', status: 'Pending' },
  ]);

  const [attendanceState, setAttendanceState] = useState('Not Started');
  const [attendanceHistory, setAttendanceHistory] = useState([
    { date: 'Oct 02, 2026', punchIn: '09:05 AM', punchOut: '06:15 PM', status: 'Present' },
    { date: 'Oct 01, 2026', punchIn: '08:55 AM', punchOut: '05:50 PM', status: 'Present' },
    { date: 'Sep 30, 2026', punchIn: '-', punchOut: '-', status: 'Absent' },
    { date: 'Sep 29, 2026', punchIn: '09:10 AM', punchOut: '06:00 PM', status: 'Present' },
    { date: 'Sep 28, 2026', punchIn: '09:00 AM', punchOut: '06:00 PM', status: 'Present' },
  ]);

  const [dashboardStats, setDashboardStats] = useState({
    totalAssigned: 1240,
    contacted: 856,
    supportive: 620,
  });

  const [activities, setActivities] = useState([
    { id: 1, type: 'users', bgColor: '#E0E7FF', color: 'var(--primary)', title: 'Marked Anjali Verma as Supportive', time: '2 hours ago • Ward 42' },
    { id: 2, type: 'clock', bgColor: '#FEF3C7', color: 'var(--warning)', title: 'Scheduled follow-up with R. K. Singh', time: '4 hours ago • Needs Info' },
    { id: 3, type: 'clipboard', bgColor: '#DCFCE7', color: 'var(--success)', title: 'Completed Booth Level Meeting', time: 'Yesterday at 5:00 PM' }
  ]);

  const pendingFollowUps = complaintsData.filter(c => c.status === 'Pending' || c.status === 'In Progress').length + meetingsList.length;

  const addActivity = (type, title, bgColor, color) => {
    setActivities(prev => [
      { id: Date.now(), type, bgColor, color, title, time: 'Just now' },
      ...prev.slice(0, 4) // Keep only recent 5
    ]);
  };

  const handlePunchInOut = () => {
    const today = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    
    if (attendanceState === 'Not Started') {
      setAttendanceState('Punched In');
      setAttendanceHistory([{ date: today, punchIn: time, punchOut: '-', status: 'Present' }, ...attendanceHistory]);
      addActivity('clock', 'Punched In for the day', '#E0E7FF', 'var(--primary)');
    } else if (attendanceState === 'Punched In') {
      setAttendanceState('Completed');
      const newHistory = [...attendanceHistory];
      if (newHistory.length > 0 && newHistory[0].date === today) {
        newHistory[0] = { ...newHistory[0], punchOut: time };
        setAttendanceHistory(newHistory);
      }
    }
  };

  const handleUpdateComplaintStatus = (id, newStatus) => {
    const complaint = complaintsData.find(c => c.id === id);
    setComplaintsData(complaintsData.map(c => c.id === id ? { ...c, status: newStatus } : c));
    addActivity('clipboard', `Updated complaint ${id} to ${newStatus}`, '#DCFCE7', 'var(--success)');
    setDashboardStats(prev => ({ ...prev, contacted: prev.contacted + 1 }));
  };

  const handleScheduleMeeting = () => {
    if(newMeeting.title) {
      setMeetingsList([{...newMeeting, attendees: newMeeting.attendees || '1 Person'}, ...meetingsList]);
      setIsSchedulingMeeting(false);
      addActivity('users', `Scheduled meeting: ${newMeeting.title}`, '#FEF3C7', 'var(--warning)');
      setNewMeeting({ title: '', time: '', location: '', attendees: '', type: 'Virtual' });
      setDashboardStats(prev => ({ ...prev, totalAssigned: prev.totalAssigned + 1 }));
    }
  };

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfileData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const saveProfile = () => {
    // Save logic
    setIsEditingProfile(false);
  };

  // Helper to render content based on active tab
  const renderContent = () => {
    if (activeTab === 'Dashboard') {
      return (
        <>
          <div className="page-header">
            <div>
              <h1 className="page-title">Dashboard Overview</h1>
              <div className="page-subtitle">Your campaign progress at a glance.</div>
            </div>
          </div>

          {/* Top Layout */}
          <div className="top-layout">
            <div className="top-left-section">
              {/* Stats Row */}
              <div className="stats-row">
                <div className="stat-card">
                  <div className="stat-icon-wrapper stat-icon-blue">
                    <Users size={20} />
                  </div>
                  <div className="stat-info">
                    <div className="stat-value">{dashboardStats.totalAssigned.toLocaleString()}</div>
                    <div className="stat-label">Total Assigned</div>
                    <div className="stat-trend trend-up">
                      <TrendingUp size={12} /> <span>+12%</span>
                    </div>
                  </div>
                </div>

                <div className="stat-card">
                  <div className="stat-icon-wrapper stat-icon-green">
                    <PhoneCall size={20} />
                  </div>
                  <div className="stat-info">
                    <div className="stat-value">{dashboardStats.contacted.toLocaleString()}</div>
                    <div className="stat-label">Contacted</div>
                    <div className="stat-trend trend-up">
                      <TrendingUp size={12} /> <span>+5%</span>
                    </div>
                  </div>
                </div>

                <div className="stat-card">
                  <div className="stat-icon-wrapper stat-icon-orange">
                    <Clock size={20} />
                  </div>
                  <div className="stat-info">
                    <div className="stat-value">{pendingFollowUps}</div>
                    <div className="stat-label">Pending Follow-ups</div>
                    <div className="stat-trend trend-down">
                      <AlertCircle size={12} /> <span>Needs attention</span>
                    </div>
                  </div>
                </div>

                <div className="stat-card">
                  <div className="stat-icon-wrapper stat-icon-blue">
                    <BarChart2 size={20} />
                  </div>
                  <div className="stat-info">
                    <div className="stat-value">{dashboardStats.supportive.toLocaleString()}</div>
                    <div className="stat-label">Supportive Voters</div>
                    <div className="stat-trend trend-up">
                      <TrendingUp size={12} /> <span>+18%</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Banner Right */}
            <div className="banner-card">
              <div className="banner-content">
                <h2 className="banner-title">Stronger<br />Communities</h2>
                <p className="banner-subtitle">Brighter Tomorrow</p>
              </div>
              <svg className="banner-illustration" viewBox="0 0 200 150" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M140 10 L140 60 L180 60 Z" fill="#FF5722"/>
                <rect x="135" y="10" width="4" height="140" fill="#475569"/>
                <circle cx="110" cy="80" r="12" fill="#1E3A8A"/>
                <path d="M90 150 C90 110, 130 110, 130 150 Z" fill="#1E3A8A"/>
                <circle cx="150" cy="90" r="10" fill="#1E3A8A"/>
                <path d="M135 150 C135 120, 165 120, 165 150 Z" fill="#1E3A8A"/>
                <circle cx="70" cy="110" r="8" fill="#3B82F6"/>
                <path d="M55 150 C55 130, 85 130, 85 150 Z" fill="#3B82F6"/>
              </svg>
            </div>
          </div>

          {/* Bottom Layout */}
          <div className="bottom-layout">
            {/* Chart Section */}
            <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
              <div className="card-header">
                <h2 className="card-title">Voter Outreach Trends</h2>
                <div className="chart-header">
                  <div className="chart-legend">
                    <div className="legend-dot"></div>
                    <span>Contacted</span>
                  </div>
                  <select className="select-dropdown">
                    <option>Last 6 Months</option>
                  </select>
                </div>
              </div>
              <div style={{ flex: 1, minHeight: '220px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={voterData} barGap={0}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dx={-10} />
                    <Tooltip 
                      cursor={{fill: '#f1f5f9'}}
                      contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    />
                    <Bar dataKey="value1" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={24} name="Contacted" />
                    <Bar dataKey="value2" fill="#93c5fd" radius={[4, 4, 0, 0]} barSize={24} name="Target" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Activities Section */}
            <div className="card">
              <div className="card-header">
                <h2 className="card-title" style={{color: 'var(--text-primary)'}}>Recent Activities</h2>
                <button className="card-action">View All</button>
              </div>
              <div className="activity-list">
                {activities.map(activity => (
                  <div className="activity-item" key={activity.id}>
                    <div className="activity-icon" style={{ backgroundColor: activity.bgColor, color: activity.color }}>
                      {activity.type === 'users' && <Users size={16} />}
                      {activity.type === 'clock' && <Clock size={16} />}
                      {activity.type === 'clipboard' && <ClipboardList size={16} />}
                    </div>
                    <div className="activity-details">
                      <div className="activity-title">{activity.title}</div>
                      <div className="activity-time">{activity.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      );
    }
    
    if (activeTab === 'User Profile') {
      return (
        <div className="profile-container">
          <div className="page-header">
            <div>
              <h1 className="page-title">User Profile</h1>
              <div className="page-subtitle">Manage your personal and campaign details.</div>
            </div>
            {isEditingProfile ? (
              <div style={{ display: 'flex', gap: '1rem' }}>
                <button className="btn-outline" onClick={() => setIsEditingProfile(false)}>
                  <X size={16} />
                  <span>Cancel</span>
                </button>
                <button className="btn-success" onClick={saveProfile}>
                  <Save size={16} />
                  <span>Save Changes</span>
                </button>
              </div>
            ) : (
              <button className="btn-primary" onClick={() => setIsEditingProfile(true)}>
                <Edit2 size={16} />
                <span>Edit Profile</span>
              </button>
            )}
          </div>

          <div className="profile-header-card">
            <div className="profile-cover"></div>
            <div className="profile-header-content">
              <div className="profile-avatar-section">
                <div className="profile-avatar-large">
                  <div className="avatar-inner">R</div>
                </div>
                <div className="profile-title">
                  <h2>{profileData.fullName.split(' ')[0]} {profileData.fullName.split(' ').slice(-1)}</h2>
                  <p><MapPin size={16} /> Mumbai, Maharashtra</p>
                  <span className="badge-role">Ward Coordinator</span>
                </div>
              </div>
              <button className="btn-outline" style={{marginTop: '1rem'}}>
                <Shield size={16} />
                <span>Change Password</span>
              </button>
            </div>
          </div>

          <div className="profile-grid">
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">Personal Information</h2>
              </div>
              <div className="info-row">
                <div className="info-group">
                  <div className="info-label">Full Name</div>
                  {isEditingProfile ? (
                    <input type="text" name="fullName" className="form-input" value={profileData.fullName} onChange={handleProfileChange} />
                  ) : (
                    <div className="info-value">{profileData.fullName}</div>
                  )}
                </div>
                <div className="info-group">
                  <div className="info-label">Date of Birth</div>
                  {isEditingProfile ? (
                    <input type="date" name="dob" className="form-input" value={profileData.dob} onChange={handleProfileChange} />
                  ) : (
                    <div className="info-value">{new Date(profileData.dob).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
                  )}
                </div>
                <div className="info-group">
                  <div className="info-label">Phone Number</div>
                  {isEditingProfile ? (
                    <input type="text" name="phone" className="form-input" value={profileData.phone} onChange={handleProfileChange} />
                  ) : (
                    <div className="info-value" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Phone size={14} color="var(--text-secondary)" />
                      {profileData.phone}
                    </div>
                  )}
                </div>
                <div className="info-group">
                  <div className="info-label">Email Address</div>
                  {isEditingProfile ? (
                    <input type="email" name="email" className="form-input" value={profileData.email} onChange={handleProfileChange} />
                  ) : (
                    <div className="info-value" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <Mail size={14} color="var(--text-secondary)" />
                      {profileData.email}
                    </div>
                  )}
                </div>
                <div className="info-group" style={{ gridColumn: '1 / -1' }}>
                  <div className="info-label">Residential Address</div>
                  {isEditingProfile ? (
                    <textarea name="address" className="form-input" value={profileData.address} onChange={handleProfileChange} rows="2"></textarea>
                  ) : (
                    <div className="info-value">{profileData.address}</div>
                  )}
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-header">
                <h2 className="card-title">Campaign Details</h2>
              </div>
              <div className="info-group">
                <div className="info-label">Assigned Ward</div>
                {isEditingProfile ? (
                  <input type="text" name="assignedWard" className="form-input" value={profileData.assignedWard} onChange={handleProfileChange} />
                ) : (
                  <div className="info-value">{profileData.assignedWard}</div>
                )}
              </div>
              <div className="info-group">
                <div className="info-label">Primary Booths</div>
                {isEditingProfile ? (
                  <input type="text" name="primaryBooths" className="form-input" value={profileData.primaryBooths} onChange={handleProfileChange} />
                ) : (
                  <div className="info-value">{profileData.primaryBooths}</div>
                )}
              </div>
              <div className="info-group">
                <div className="info-label">Join Date</div>
                {isEditingProfile ? (
                  <input type="date" name="joinDate" className="form-input" value={profileData.joinDate} onChange={handleProfileChange} />
                ) : (
                  <div className="info-value" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <CalendarDays size={14} color="var(--text-secondary)" />
                    {new Date(profileData.joinDate).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                  </div>
                )}
              </div>
              <div className="info-group">
                <div className="info-label">Voter ID (EPIC)</div>
                {isEditingProfile ? (
                  <input type="text" name="epic" className="form-input" value={profileData.epic} onChange={handleProfileChange} />
                ) : (
                  <div className="info-value">{profileData.epic}</div>
                )}
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (activeTab === 'Contact & Meetings') {
      return (
        <div className="module-container" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="page-header" style={{ marginBottom: 0 }}>
            <div>
              <h1 className="page-title">Contact & Meetings</h1>
              <div className="page-subtitle">Manage your network and schedule campaign meetings.</div>
            </div>
            <div style={{ display: 'flex', gap: '0.25rem', backgroundColor: 'white', padding: '0.25rem', borderRadius: 'var(--radius)', border: '1px solid var(--border)' }}>
              <button 
                onClick={() => setContactTab('contacts')}
                style={{ 
                  padding: '0.5rem 1.25rem', 
                  borderRadius: 'var(--radius-sm)', 
                  border: 'none', 
                  background: contactTab === 'contacts' ? 'var(--bg-light-blue)' : 'transparent', 
                  color: contactTab === 'contacts' ? 'var(--primary)' : 'var(--text-secondary)', 
                  fontWeight: 500, 
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
              >
                Contacts
              </button>
              <button 
                onClick={() => setContactTab('meetings')}
                style={{ 
                  padding: '0.5rem 1.25rem', 
                  borderRadius: 'var(--radius-sm)', 
                  border: 'none', 
                  background: contactTab === 'meetings' ? 'var(--bg-light-blue)' : 'transparent', 
                  color: contactTab === 'meetings' ? 'var(--primary)' : 'var(--text-secondary)', 
                  fontWeight: 500, 
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
              >
                Meetings
              </button>
            </div>
          </div>

          {contactTab === 'contacts' && (
            <div className="card">
              <div className="card-header">
                <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                  <h2 className="card-title">My Contacts</h2>
                  <div className="header-search" style={{ width: '250px', padding: '0.35rem 1rem' }}>
                    <Search size={14} color="#94a3b8" />
                    <input type="text" placeholder="Search contacts..." style={{ fontSize: '0.75rem' }} />
                  </div>
                </div>
              </div>
              
              <div style={{ overflowX: 'auto' }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Phone</th>
                      <th>Role / Info</th>
                      <th>Status</th>
                      <th style={{ textAlign: 'right' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { name: 'Sanjay Patil', phone: '+91 91234 56780', role: 'Booth Adhyaksh', status: 'Active' },
                      { name: 'Priya Sharma', phone: '+91 87654 32109', role: 'Voter', status: 'Pending' },
                      { name: 'Amit Desai', phone: '+91 76543 21098', role: 'Volunteer', status: 'Active' },
                      { name: 'Sunita Verma', phone: '+91 99887 76655', role: 'Voter', status: 'Follow Up' }
                    ].map((contact, i) => (
                      <tr key={i}>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                            <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: 'var(--bg-light-blue)', color: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, fontSize: '0.75rem' }}>
                              {contact.name.charAt(0)}
                            </div>
                            <span style={{ fontWeight: 500 }}>{contact.name}</span>
                          </div>
                        </td>
                        <td style={{ color: 'var(--text-secondary)' }}>{contact.phone}</td>
                        <td>{contact.role}</td>
                        <td>
                          <span className={`badge-status ${contact.status === 'Active' ? 'status-completed' : contact.status === 'Pending' ? 'status-pending' : 'status-progress'}`}>
                            {contact.status}
                          </span>
                        </td>
                        <td>
                          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
                            <button className="icon-btn icon-btn-primary" title="Call">
                              <PhoneCall size={16} color="var(--primary)" />
                            </button>
                            <button className="icon-btn icon-btn-success" title="Message">
                              <MessageCircle size={16} color="var(--success)" />
                            </button>
                            <button className="icon-btn">
                              <MoreVertical size={16} color="var(--text-secondary)" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {contactTab === 'meetings' && (
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">{isSchedulingMeeting ? 'Schedule New Meeting' : 'Upcoming Meetings'}</h2>
                {!isSchedulingMeeting && (
                  <button className="btn-primary" onClick={() => setIsSchedulingMeeting(true)}>
                    <Plus size={16} />
                    <span>Schedule Meeting</span>
                  </button>
                )}
              </div>
              
              {isSchedulingMeeting ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxWidth: '600px' }}>
                  <div className="info-group">
                    <label className="info-label">Meeting Title</label>
                    <input type="text" className="form-input" placeholder="e.g. Ward Sync" value={newMeeting.title} onChange={(e) => setNewMeeting({...newMeeting, title: e.target.value})} />
                  </div>
                  <div className="info-row">
                    <div className="info-group">
                      <label className="info-label">Date & Time</label>
                      <input type="text" className="form-input" placeholder="e.g. Oct 10, 5:00 PM" value={newMeeting.time} onChange={(e) => setNewMeeting({...newMeeting, time: e.target.value})} />
                    </div>
                    <div className="info-group">
                      <label className="info-label">Meeting Type</label>
                      <select className="form-input" value={newMeeting.type} onChange={(e) => setNewMeeting({...newMeeting, type: e.target.value})}>
                        <option value="Virtual">Virtual</option>
                        <option value="In-person">In-person</option>
                      </select>
                    </div>
                  </div>
                  <div className="info-row">
                    <div className="info-group">
                      <label className="info-label">Location / Link</label>
                      <input type="text" className="form-input" placeholder="Address or URL" value={newMeeting.location} onChange={(e) => setNewMeeting({...newMeeting, location: e.target.value})} />
                    </div>
                    <div className="info-group">
                      <label className="info-label">Attendees</label>
                      <input type="text" className="form-input" placeholder="e.g. 5 People" value={newMeeting.attendees} onChange={(e) => setNewMeeting({...newMeeting, attendees: e.target.value})} />
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
                    <button className="btn-outline" onClick={() => setIsSchedulingMeeting(false)}>Cancel</button>
                    <button className="btn-success" onClick={handleScheduleMeeting}>Schedule Meeting</button>
                  </div>
                </div>
              ) : (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem' }}>
                  {meetingsList.map((meeting, i) => (
                    <div key={i} style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <div style={{ padding: '0.5rem', backgroundColor: meeting.type === 'Virtual' ? '#E0E7FF' : '#FEF3C7', color: meeting.type === 'Virtual' ? 'var(--primary)' : 'var(--warning)', borderRadius: 'var(--radius-sm)' }}>
                          {meeting.type === 'Virtual' ? <Video size={20} /> : <Users size={20} />}
                        </div>
                        <span style={{ fontSize: '0.75rem', fontWeight: 500, color: 'var(--text-secondary)', backgroundColor: 'var(--bg-main)', padding: '0.25rem 0.5rem', borderRadius: '9999px' }}>
                          {meeting.type}
                        </span>
                      </div>
                      
                      <div>
                        <h3 style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '0.25rem' }}>{meeting.title}</h3>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-secondary)', fontSize: '0.875rem', marginBottom: '0.25rem' }}>
                          <Clock size={14} /> {meeting.time}
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
                          <MapPin size={14} /> {meeting.location}
                        </div>
                      </div>
                      
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: '1rem', borderTop: '1px solid var(--border)' }}>
                        <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', fontWeight: 500 }}>{meeting.attendees}</span>
                        <button style={{ color: 'var(--primary)', fontWeight: 600, fontSize: '0.875rem', background: 'transparent', border: 'none', cursor: 'pointer' }}>Manage</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      );
    }
    
    if (activeTab === 'Complaints') {
      const filteredComplaints = complaintFilter === 'All' ? complaintsData : complaintsData.filter(c => c.status === complaintFilter);
      
      return (
        <div className="module-container" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="page-header" style={{ marginBottom: 0 }}>
            <div>
              <h1 className="page-title">Complaints Management</h1>
              <div className="page-subtitle">Track and resolve issues reported by citizens.</div>
            </div>
            <div style={{ display: 'flex', gap: '1rem' }}>
              <div className="header-search" style={{ width: '250px', padding: '0.35rem 1rem' }}>
                <Search size={14} color="#94a3b8" />
                <input type="text" placeholder="Search ID, Name or Category" style={{ fontSize: '0.75rem' }} />
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-header" style={{ borderBottom: '1px solid var(--border)', paddingBottom: '1rem', marginBottom: '1rem' }}>
              <div style={{ display: 'flex', gap: '1.5rem' }}>
                {['All', 'Pending', 'Action Taken', 'In Progress', 'Resolved'].map(filter => (
                  <button 
                    key={filter}
                    onClick={() => setComplaintFilter(filter)}
                    style={{ 
                      padding: '0.25rem 0', 
                      border: 'none', 
                      background: 'transparent',
                      color: complaintFilter === filter ? 'var(--primary)' : 'var(--text-secondary)',
                      fontWeight: complaintFilter === filter ? 600 : 500,
                      borderBottom: complaintFilter === filter ? '2px solid var(--primary)' : '2px solid transparent',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                      marginBottom: '-1rem'
                    }}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ overflowX: 'auto' }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Citizen Details</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th style={{ textAlign: 'right' }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredComplaints.map((complaint, i) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 600, color: 'var(--primary)' }}>{complaint.id}</td>
                      <td>
                        <div style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{complaint.name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{complaint.phone}</div>
                      </td>
                      <td>
                        <span style={{ backgroundColor: 'var(--bg-main)', padding: '0.25rem 0.5rem', borderRadius: '4px', fontSize: '0.75rem', fontWeight: 500 }}>
                          {complaint.category}
                        </span>
                      </td>
                      <td style={{ maxWidth: '200px' }}>
                        <div style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} title={complaint.desc}>
                          {complaint.desc}
                        </div>
                      </td>
                      <td style={{ color: 'var(--text-secondary)' }}>{complaint.date}</td>
                      <td>
                        <span className={`badge-status ${complaint.status === 'Resolved' ? 'status-completed' : complaint.status === 'In Progress' ? 'status-progress' : complaint.status === 'Action Taken' ? 'status-completed' : 'status-pending'}`} style={complaint.status === 'Action Taken' ? {backgroundColor: '#DBEAFE', color: 'var(--primary)'} : {}}>
                          {complaint.status}
                        </span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
                          <button 
                            className="icon-btn icon-btn-primary" 
                            title="Action Taken"
                            onClick={() => handleUpdateComplaintStatus(complaint.id, 'Action Taken')}
                          >
                            <Play size={16} color="var(--primary)" />
                          </button>
                          <button 
                            className="icon-btn icon-btn-warning" 
                            title="In Progress"
                            onClick={() => handleUpdateComplaintStatus(complaint.id, 'In Progress')}
                          >
                            <Clock size={16} color="var(--warning)" />
                          </button>
                          <button 
                            className="icon-btn icon-btn-success" 
                            title="Mark as Resolved"
                            onClick={() => handleUpdateComplaintStatus(complaint.id, 'Resolved')}
                          >
                            <CheckCheck size={16} color="var(--success)" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
    }
    
    if (activeTab === 'Attendance') {
      return (
        <div className="module-container" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="page-header" style={{ marginBottom: 0 }}>
            <div>
              <h1 className="page-title">Attendance Tracking</h1>
              <div className="page-subtitle">Mark your daily attendance and view your history.</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '1.5rem' }}>
            <div className="card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '3rem 2rem', gap: '2rem' }}>
              <div style={{ textAlign: 'center' }}>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--text-primary)', marginBottom: '0.5rem' }}>Current Status</h3>
                <span className={`badge-status ${attendanceState === 'Punched In' ? 'status-progress' : attendanceState === 'Completed' ? 'status-completed' : 'status-pending'}`} style={{ fontSize: '1rem', padding: '0.5rem 1rem' }}>
                  {attendanceState === 'Punched In' ? 'On Duty (Punched In)' : attendanceState === 'Completed' ? 'Shift Completed' : 'Off Duty (Not Started)'}
                </span>
              </div>
              
              <button 
                onClick={handlePunchInOut}
                disabled={attendanceState === 'Completed'}
                style={{
                  width: '180px',
                  height: '180px',
                  borderRadius: '50%',
                  backgroundColor: attendanceState === 'Completed' ? '#F3F4F6' : attendanceState === 'Punched In' ? '#FEE2E2' : 'var(--primary)',
                  color: attendanceState === 'Completed' ? '#9CA3AF' : attendanceState === 'Punched In' ? '#DC2626' : 'white',
                  border: `8px solid ${attendanceState === 'Completed' ? '#E5E7EB' : attendanceState === 'Punched In' ? '#FECACA' : '#BFDBFE'}`,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '1rem',
                  cursor: attendanceState === 'Completed' ? 'not-allowed' : 'pointer',
                  transition: 'all 0.3s ease',
                  boxShadow: attendanceState === 'Completed' ? 'none' : '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
                  fontSize: '1.25rem',
                  fontWeight: 600
                }}
              >
                <UserCheck size={48} />
                <span>{attendanceState === 'Completed' ? 'Done for Today' : attendanceState === 'Punched In' ? 'Punch Out' : 'Punch In'}</span>
              </button>
              
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', textAlign: 'center' }}>
                {attendanceState === 'Completed' ? 'Great job today! See you tomorrow.' : attendanceState === 'Punched In' ? 'Remember to punch out when your shift ends.' : 'Punch in to start your work day.'}
              </p>
            </div>

            <div className="card" style={{ padding: '1.5rem' }}>
              <h3 style={{ fontSize: '1.125rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '1.5rem' }}>Attendance History</h3>
              <div style={{ overflowX: 'auto' }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Punch In</th>
                      <th>Punch Out</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {attendanceHistory.map((record, i) => (
                      <tr key={i}>
                        <td style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{record.date}</td>
                        <td style={{ color: 'var(--text-secondary)' }}>{record.punchIn}</td>
                        <td style={{ color: 'var(--text-secondary)' }}>{record.punchOut}</td>
                        <td>
                          <span className={`badge-status ${record.status === 'Present' ? 'status-completed' : 'status-progress'}`} style={record.status === 'Absent' ? {backgroundColor: '#FEE2E2', color: '#DC2626'} : {}}>
                            {record.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      );
    }
    
    // Default placeholder for other tabs
    return (
      <div className="card" style={{ marginTop: '2rem', textAlign: 'center', padding: '4rem 2rem' }}>
        <h2 style={{ fontSize: '1.5rem', color: 'var(--secondary)', marginBottom: '1rem' }}>
          {activeTab} Module
        </h2>
        <p style={{ color: 'var(--text-secondary)' }}>
          This section is currently under development. Content for {activeTab} will appear here.
        </p>
      </div>
    );
  };

  // Main Render
  if (!isLoggedIn) {
    return (
      <div style={{ height: '100vh', width: '100vw', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#F8FAFC' }}>
        <div style={{ width: '400px', backgroundColor: 'white', padding: '3rem 2.5rem', borderRadius: '16px', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)' }}>
          <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
            <div style={{ width: '60px', height: '60px', backgroundColor: 'var(--primary)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem auto', boxShadow: '0 4px 6px -1px rgba(37, 99, 235, 0.2)' }}>
              <Users size={32} color="white" />
            </div>
            <h1 style={{ fontSize: '1.75rem', fontWeight: '700', color: '#1E293B', marginBottom: '0.5rem' }}>Karyakarta Portal</h1>
            <p style={{ color: '#64748B', fontSize: '0.95rem' }}>Enter your credentials to access your dashboard</p>
          </div>
          
          <form onSubmit={(e) => { e.preventDefault(); setIsLoggedIn(true); }}>
            <div style={{ marginBottom: '1.5rem' }}>
              <label style={{ display: 'block', marginBottom: '0.5rem', color: '#475569', fontWeight: '500', fontSize: '0.875rem' }}>Mobile Number or Email</label>
              <input type="text" placeholder="Enter your registered mobile or email" required style={{ width: '100%', padding: '0.75rem 1rem', borderRadius: '8px', border: '1px solid #CBD5E1', fontSize: '0.95rem', outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div style={{ marginBottom: '2rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <label style={{ color: '#475569', fontWeight: '500', fontSize: '0.875rem' }}>Password</label>
                <a href="#" style={{ color: 'var(--primary)', fontSize: '0.875rem', textDecoration: 'none', fontWeight: '500' }}>Forgot?</a>
              </div>
              <input type="password" placeholder="••••••••" required style={{ width: '100%', padding: '0.75rem 1rem', borderRadius: '8px', border: '1px solid #CBD5E1', fontSize: '0.95rem', outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <button type="submit" style={{ width: '100%', backgroundColor: 'var(--primary)', color: 'white', padding: '0.875rem', borderRadius: '8px', fontWeight: '600', fontSize: '1rem', border: 'none', cursor: 'pointer', transition: 'background-color 0.2s', boxShadow: '0 4px 6px -1px rgba(37, 99, 235, 0.2)' }}>
              Sign In
            </button>
          </form>
          
          <div style={{ marginTop: '2rem', textAlign: 'center', fontSize: '0.875rem', color: '#64748B' }}>
            Don't have an account? <a href="#" style={{ color: 'var(--primary)', fontWeight: '600', textDecoration: 'none' }}>Contact Admin</a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="layout">
      {/* Sidebar */}
      <aside className={`sidebar ${isSidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <div className="logo-icon">
            <Users size={28} />
          </div>
          <div className="logo-text">
            Karyakarta<br />Portal
          </div>
        </div>
        
        <nav className="sidebar-nav">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button 
                key={item.name}
                className={`nav-item ${activeTab === item.name ? 'active' : ''}`}
                onClick={() => setActiveTab(item.name)}
              >
                <div className="nav-item-left">
                  <Icon className="nav-icon" />
                  <span>{item.name}</span>
                </div>
                {item.badge && <span className="nav-badge">{item.badge}</span>}
              </button>
            );
          })}
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-promo">
            <div className="promo-icon">
              <Target size={20} color="white" />
            </div>
            <div className="promo-text">
              <h4>Be the Change</h4>
              <p>Join the Movement</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Wrapper */}
      <main className="main-wrapper">
        {/* Top Header */}
        <header className="header">
          <div className="flex items-center gap-4">
            <button 
              className="icon-btn lg:hidden" 
              onClick={() => setSidebarOpen(!isSidebarOpen)}
              style={{ display: 'none' /* Handled via media queries normally */ }}
            >
              <Menu size={20} />
            </button>
            <div className="header-search">
              <Search size={18} color="#94a3b8" />
              <input type="text" placeholder="Search voters, tasks, messages..." />
            </div>
          </div>

          <div className="header-actions">
            <button className="icon-btn" style={{ background: 'transparent', boxShadow: 'none' }}>
              <Bell size={20} />
              <span className="badge"></span>
            </button>
            <div className="user-profile">
              <div className="avatar">R</div>
              <div className="user-info">
                <div className="user-name">Rahul Sharma</div>
                <div className="user-role">Ward Coordinator</div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="content">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;
